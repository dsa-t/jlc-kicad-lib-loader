from .easyeda_3d_loader import EasyEDALoaderPlugin

EasyEDALoaderPlugin().register()